package Satge2.HW01;

interface Info {
    public void ShowInfo();
    public int GetJump();
    public int GetRun();
    public void SetParticipiant();
    public int GetParticipiant();
    public void ShoWin();
}

