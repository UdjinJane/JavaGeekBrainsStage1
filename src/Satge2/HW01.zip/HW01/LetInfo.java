package Satge2.HW01;

interface LetInfo {
        public int GetLet();
}
